let cart = [];

function addToCart(id, name, price, qtySelectId) {
    const quantity = parseInt(document.getElementById(qtySelectId).value);
    
    const existingItem = cart.find(item => item.id === id);
    
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({
            id: id,
            name: name,
            price: price,
            quantity: quantity
        });
    }
    
    updateCartDisplay();
    showCart();
    
    // Show success message
    alert(`${name} added to cart!`);
}

function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    updateCartDisplay();
    
    if (cart.length === 0) {
        hideCart();
    }
}

function updateCartDisplay() {
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    
    if (!cartItems || !cartTotal) return;
    
    cartItems.innerHTML = '';
    let total = 0;
    
    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        cartItems.innerHTML += `
            <div class="cart-item">
                <div>
                    <h4>${item.name}</h4>
                    <p>PKR ${item.price.toLocaleString()} x ${item.quantity} = PKR ${itemTotal.toLocaleString()}</p>
                </div>
                <button class="remove-btn" onclick="removeFromCart('${item.id}')">Remove</button>
            </div>
        `;
    });
    
    cartTotal.textContent = total.toLocaleString();
}

function showCart() {
    const cartSection = document.getElementById('cart-section');
    if (cartSection) {
        cartSection.style.display = 'block';
        cartSection.scrollIntoView({ behavior: 'smooth' });
    }
}

function hideCart() {
    const cartSection = document.getElementById('cart-section');
    if (cartSection) {
        cartSection.style.display = 'none';
    }
}

function checkout() {
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    alert(`Total: PKR ${total.toLocaleString()}\nRedirecting to checkout...`);
    
    // Clear cart after checkout
    cart = [];
    updateCartDisplay();
    hideCart();
}
