// Contact Form Handler
document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        subject: document.getElementById('subject').value,
        message: document.getElementById('message').value,
        newsletter: document.getElementById('newsletter').checked
    };
    
    // Clear previous errors
    clearErrors();
    
    // Validate form
    if (validateContactForm(formData)) {
        // Show loading state
        showLoading(true);
        
        // Simulate API call delay
        setTimeout(() => {
            // Store contact submission
            storeContactSubmission(formData);
            
            // Show success message
            showLoading(false);
            showSuccessMessage();
            
            // Reset form
            document.getElementById('contactForm').reset();
            
        }, 2000);
    }
});

// Validation function
function validateContactForm(data) {
    let isValid = true;
    
    // First Name validation
    if (data.firstName.length < 2) {
        showError('firstName', 'First name must be at least 2 characters');
        isValid = false;
    }
    
    // Last Name validation
    if (data.lastName.length < 2) {
        showError('lastName', 'Last name must be at least 2 characters');
        isValid = false;
    }
    
    // Email validation
    if (!validateEmail(data.email)) {
        showError('email', 'Please enter a valid email address');
        isValid = false;
    }
    
    // Subject validation
    if (!data.subject) {
        showError('subject', 'Please select a subject');
        isValid = false;
    }
    
    // Message validation
    if (data.message.length < 10) {
        showError('message', 'Message must be at least 10 characters');
        isValid = false;
    }
    
    return isValid;
}

// Email validation
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Store contact submission
function storeContactSubmission(data) {
    let contacts = JSON.parse(localStorage.getItem('contactSubmissions')) || [];
    
    const newContact = {
        id: Date.now(),
        ...data,
        submissionDate: new Date().toISOString()
    };
    
    contacts.push(newContact);
    localStorage.setItem('contactSubmissions', JSON.stringify(contacts));
}

// UI Helper functions
function showError(fieldId, message) {
    const field = document.getElementById(fieldId);
    field.style.borderColor = '#e74c3c';
    
    // Create or update error message
    let errorElement = field.parentNode.querySelector('.error-message');
    if (!errorElement) {
        errorElement = document.createElement('span');
        errorElement.className = 'error-message';
        errorElement.style.color = '#e74c3c';
        errorElement.style.fontSize = '0.9rem';
        errorElement.style.marginTop = '0.5rem';
        errorElement.style.display = 'block';
        field.parentNode.appendChild(errorElement);
    }
    errorElement.textContent = message;
}

function clearErrors() {
    const errorElements = document.querySelectorAll('.error-message');
    errorElements.forEach(element => {
        element.remove();
    });
    
    // Reset field borders
    const fields = document.querySelectorAll('#contactForm input, #contactForm select, #contactForm textarea');
    fields.forEach(field => {
        field.style.borderColor = '#e1e8ed';
    });
}

function showLoading(show) {
    const btnText = document.querySelector('.btn-text');
    const btnLoader = document.querySelector('.btn-loader');
    const submitBtn = document.querySelector('.btn-submit');
    
    if (show) {
        btnText.style.display = 'none';
        btnLoader.style.display = 'inline';
        submitBtn.disabled = true;
        submitBtn.style.opacity = '0.7';
    } else {
        btnText.style.display = 'inline';
        btnLoader.style.display = 'none';
        submitBtn.disabled = false;
        submitBtn.style.opacity = '1';
    }
}

function showSuccessMessage() {
    // Create success modal
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
    `;
    
    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
        background: white;
        padding: 2rem;
        border-radius: 20px;
        text-align: center;
        max-width: 400px;
        margin: 0 1rem;
    `;
    
    modalContent.innerHTML = `
        <div style="font-size: 3rem; margin-bottom: 1rem;">✅</div>
        <h3 style="color: #27ae60; margin-bottom: 1rem;">Message Sent Successfully!</h3>
        <p style="color: #666; margin-bottom: 1.5rem;">Thank you for contacting us. We'll get back to you within 24 hours.</p>
        <button onclick="this.closest('.success-modal').remove()" style="
            background: #27ae60;
            color: white;
            border: none;
            padding: 0.8rem 2rem;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 600;
        ">Close</button>
    `;
    
    modal.className = 'success-modal';
    modal.appendChild(modalContent);
    document.body.appendChild(modal);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (modal.parentNode) {
            modal.remove();
        }
    }, 5000);
}

// FAQ Toggle functionality
document.addEventListener('DOMContentLoaded', function() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all other FAQ items
            faqItems.forEach(otherItem => {
                otherItem.classList.remove('active');
                otherItem.querySelector('.faq-answer').classList.remove('active');
            });
            
            // Toggle current item
            if (!isActive) {
                item.classList.add('active');
                answer.classList.add('active');
            }
        });
    });
});

