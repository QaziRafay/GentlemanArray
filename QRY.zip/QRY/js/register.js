// Registration System for Gentleman Array

// Register Form Handler
document.getElementById('registerForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        country: document.getElementById('country').value,
        phone: document.getElementById('phone').value,
        email: document.getElementById('regEmail').value,
        password: document.getElementById('regPassword').value,
        confirmPassword: document.getElementById('confirmPassword').value,
        agreeTerms: document.getElementById('agreeTerms').checked
    };
    
    // Clear previous errors
    clearErrors();
    
    // Validate all fields
    if (validateRegistration(formData)) {
        // Show loading state
        showLoading(true);
        
        // Simulate API call delay
        setTimeout(() => {
            // Store user data
            registerUser(formData);
            
            // Show success and redirect
            showLoading(false);
            showSuccessModal();
            
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2500);
            
        }, 2000);
    }
});

// Validation function
function validateRegistration(data) {
    let isValid = true;
    
    // First Name validation
    if (data.firstName.length < 2) {
        showError('firstNameError', 'First name must be at least 2 characters');
        isValid = false;
    }
    
    // Last Name validation
    if (data.lastName.length < 2) {
        showError('lastNameError', 'Last name must be at least 2 characters');
        isValid = false;
    }
    
    // Country validation
    if (!data.country) {
        showError('countryError', 'Please select your country');
        isValid = false;
    }
    
    // Phone validation
    if (data.phone.length < 10) {
        showError('phoneError', 'Please enter a valid phone number');
        isValid = false;
    }
    
    // Email validation
    if (!validateEmail(data.email)) {
        showError('regEmailError', 'Please enter a valid email address');
        isValid = false;
    }
    
    // Password validation
    if (data.password.length < 6) {
        showError('regPasswordError', 'Password must be at least 6 characters');
        isValid = false;
    }
    
    // Confirm password validation
    if (data.password !== data.confirmPassword) {
        showError('confirmPasswordError', 'Passwords do not match');
        isValid = false;
    }
    
    // Terms agreement validation
    if (!data.agreeTerms) {
        alert('Please agree to the Terms & Conditions');
        isValid = false;
    }
    
    return isValid;
}

// Register user function
function registerUser(userData) {
    // Get existing users from localStorage
    let users = JSON.parse(localStorage.getItem('registeredUsers')) || [];
    
    // Check if email already exists
    const existingUser = users.find(user => user.email === userData.email);
    if (existingUser) {
        showError('regEmailError', 'Email already registered');
        showLoading(false);
        return false;
    }
    
    // Add new user
    const newUser = {
        id: Date.now(),
        firstName: userData.firstName,
        lastName: userData.lastName,
        name: `${userData.firstName} ${userData.lastName}`,
        email: userData.email,
        password: userData.password,
        country: userData.country,
        phone: userData.phone,
        registrationDate: new Date().toISOString()
    };
    
    users.push(newUser);
    localStorage.setItem('registeredUsers', JSON.stringify(users));
    
    return true;
}

// Email validation
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// UI Helper functions
function showError(elementId, message) {
    const errorElement = document.getElementById(elementId);
    errorElement.textContent = message;
    errorElement.style.display = 'block';
}

function clearErrors() {
    const errorElements = document.querySelectorAll('.error-message');
    errorElements.forEach(element => {
        element.textContent = '';
        element.style.display = 'none';
    });
}

function showLoading(show) {
    const btnText = document.querySelector('.btn-text');
    const btnLoader = document.querySelector('.btn-loader');
    const submitBtn = document.querySelector('.btn-login');
    
    if (show) {
        btnText.style.display = 'none';
        btnLoader.style.display = 'inline';
        submitBtn.disabled = true;
        submitBtn.style.opacity = '0.7';
    } else {
        btnText.style.display = 'inline';
        btnLoader.style.display = 'none';
        submitBtn.disabled = false;
        submitBtn.style.opacity = '1';
    }
}

function showSuccessModal() {
    const modal = document.getElementById('successModal');
    modal.style.display = 'flex';
}