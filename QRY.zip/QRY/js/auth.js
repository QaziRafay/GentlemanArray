// Authentication System for Gentleman Array

// Sample user database (in real app, this would be server-side)
const users = [
    { email: "admin@gentlemanarray.com", password: "admin123", name: "Admin User" },
    { email: "user@example.com", password: "password123", name: "John Doe" },
    { email: "test@test.com", password: "test123", name: "Test User" }
];

// Check if user is already logged in
document.addEventListener('DOMContentLoaded', function() {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser && window.location.pathname.includes('login.html')) {
        showSuccessMessage('Already logged in! Redirecting...');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1500);
    }
});

// Login Form Handler
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('rememberMe').checked;
    
    // Clear previous errors
    clearErrors();
    
    // Validate inputs
    if (!validateEmail(email)) {
        showError('emailError', 'Please enter a valid email address');
        return;
    }
    
    if (password.length < 6) {
        showError('passwordError', 'Password must be at least 6 characters');
        return;
    }
    
    // Show loading state
    showLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
        const user = authenticateUser(email, password);
        
        if (user) {
            // Store user session
            const userData = {
                email: user.email,
                name: user.name,
                loginTime: new Date().toISOString()
            };
            
            if (rememberMe) {
                localStorage.setItem('currentUser', JSON.stringify(userData));
            } else {
                sessionStorage.setItem('currentUser', JSON.stringify(userData));
            }
            
            // Show success and redirect
            showLoading(false);
            showSuccessModal();
            
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 2000);
            
        } else {
            showLoading(false);
            showError('passwordError', 'Invalid email or password');
        }
    }, 1500);
});

// Authentication function
function authenticateUser(email, password) {
    return users.find(user => user.email === email && user.password === password);
}

// Validation functions
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// UI Helper functions
function showError(elementId, message) {
    const errorElement = document.getElementById(elementId);
    errorElement.textContent = message;
    errorElement.style.display = 'block';
}

function clearErrors() {
    const errorElements = document.querySelectorAll('.error-message');
    errorElements.forEach(element => {
        element.textContent = '';
        element.style.display = 'none';
    });
}

function showLoading(show) {
    const btnText = document.querySelector('.btn-text');
    const btnLoader = document.querySelector('.btn-loader');
    const submitBtn = document.querySelector('.btn-login');
    
    if (show) {
        btnText.style.display = 'none';
        btnLoader.style.display = 'inline';
        submitBtn.disabled = true;
        submitBtn.style.opacity = '0.7';
    } else {
        btnText.style.display = 'inline';
        btnLoader.style.display = 'none';
        submitBtn.disabled = false;
        submitBtn.style.opacity = '1';
    }
}

function showSuccessModal() {
    const modal = document.getElementById('successModal');
    modal.style.display = 'flex';
    
    setTimeout(() => {
        modal.style.display = 'none';
    }, 3000);
}

function showSuccessMessage(message) {
    const modal = document.getElementById('successModal');
    const modalBody = modal.querySelector('.modal-body p');
    modalBody.textContent = message;
    modal.style.display = 'flex';
}

// Social Login functions
function socialLogin(provider) {
    showSuccessMessage(`Redirecting to ${provider} login...`);
    
    setTimeout(() => {
        // Simulate successful social login
        const userData = {
            email: `user@${provider}.com`,
            name: `${provider} User`,
            loginTime: new Date().toISOString()
        };
        
        localStorage.setItem('currentUser', JSON.stringify(userData));
        window.location.href = 'index.html';
    }, 2000);
}

// Logout function (can be called from other pages)
function logout() {
    localStorage.removeItem('currentUser');
    sessionStorage.removeItem('currentUser');
    window.location.href = 'login.html';
}

// Check authentication status (for other pages)
function isAuthenticated() {
    return localStorage.getItem('currentUser') || sessionStorage.getItem('currentUser');
}

// Get current user data
function getCurrentUser() {
    const userData = localStorage.getItem('currentUser') || sessionStorage.getItem('currentUser');
    return userData ? JSON.parse(userData) : null;
}